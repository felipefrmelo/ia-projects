from resources.HashGame import HashGame
from resources.Player import * 

moves=[(1, 1), (1, 2), (1, 3), (2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (3, 3)]

####
    
node=HashGame({},None,0,moves,0,'X')


def jogo():

    jogadores=[h_player,minimax_player,random_player]
    j=[]
    str_jg='\n0 : h_player\n1 : minmax_player\n2 : random_player\n' 
    for i in range(1,3):
        j.append(int(input('Escolha o jogador '+str(i)+str_jg)))

    print('Jogador 1 : ' +jogadores[j[0]].__name__,
          '\nJogador 2 : '+jogadores[j[1]].__name__,
          '\n\tStart')
    node.play_game(jogadores[j[0]],jogadores[j[1]])


    
if __name__ == '__main__':
    jogo()
